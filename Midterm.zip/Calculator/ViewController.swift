//
//  ViewController.swift
//  Calculator
//
//  Created by Alvin on 2022/3/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var step: UILabel!
    @IBOutlet weak var result: UILabel!
    @IBOutlet var buttons: [UIButton]!
    @IBOutlet weak var clearButton: UIButton!
    
    var pressedList = [String]()
    var lastOperation: String = ""
    var lastOpButton: UIButton = UIButton()
    var floated: Bool = false
    
    //    #colorLiteral(red: 0.9333333333, green: 0.8705882353, blue: 0.8823529412, alpha: 1)
    //    #colorLiteral(red: 0.5098039216, green: 0.4509803922, blue: 0.5921568627, alpha: 1)
    //    #colorLiteral(red: 0.3019607843, green: 0.2980392157, blue: 0.4901960784, alpha: 1)
    //    #colorLiteral(red: 0.2117647059, green: 0.1882352941, blue: 0.3843137255, alpha: 1)

    @IBAction func clear(_ sender: UIButton) {
        let text: String = step.text ?? ""
        let index = text.count - 1
        let lastElement = pressedList.last
        let clearType = clearButton.currentTitle!
        if clearType == "C" {
            switch lastElement {
            case "+", "-", "x", "÷":
                step.text = text
            case ".":
                step.text = String(text.prefix(index))
                pressedList.removeLast()
                floated = false
            default:
                if index >= 0 {
                    step.text = String(text.prefix(index))
                    pressedList.removeLast()
                }
                switch pressedList.last {
                case "+", "-", "x", "÷":
                    lastOpButton.backgroundColor = #colorLiteral(red: 0.9333333333, green: 0.8705882353, blue: 0.8823529412, alpha: 1)
                default:
                    break
                }
            }
            clearButton.setTitle("AC", for: .normal)
            lastOperation = "C"
        }
        if clearType == "AC" {
            step.text = ""
            result.text = "0"
            floated = false
            pressedList = [String]()
            lastOpButton.backgroundColor = #colorLiteral(red: 0.3019607843, green: 0.2980392157, blue: 0.4901960784, alpha: 1)
            lastOperation = ""
            lastOpButton = UIButton()
            clearButton.setTitle("C", for: .normal)
        }
    }
    
    func checkClear() {
        if lastOperation == "C" {
            clearButton.setTitle("C", for: .normal)
        }
    }
    
    @IBAction func operationPressed(_ sender: UIButton) {
        checkClear()
        var text: String = step.text ?? ""
        let lastElement = pressedList.last
        if text == "" {
            text = "0"
        }
        if let op = sender.currentTitle {
            switch lastElement {
            case "+", "-", "x", "÷":
                step.text = String(text.prefix(text.count - 1))
                pressedList.removeLast()
            default:
                step.text = text
            }
            let text: String = step.text ?? ""
            switch op {
            case "÷":
                step.text = text + "/"
            case "x":
                step.text = text + "*"
            default:
                step.text = text + op
            }
            if lastOperation != "" {
                lastOpButton.backgroundColor = #colorLiteral(red: 0.3019607843, green: 0.2980392157, blue: 0.4901960784, alpha: 1)
            }
            sender.backgroundColor = #colorLiteral(red: 0.9333333333, green: 0.8705882353, blue: 0.8823529412, alpha: 1)
            pressedList.append(op)
            lastOperation = op
            lastOpButton = sender
            floated = false
        }
    }
    
    @IBAction func buttonPressed(_ sender: UIButton) {
        checkClear()
        let text: String = step.text ?? ""
        let op = sender.currentTitle!
        
        switch op {
        case "+/-":
            if text == "" {
                pressedList.append("-")
                pressedList.append("0")
                step.text = "-0"
                return
            }
            switch pressedList.first {
            case "-":
                pressedList[0] = "+"
                step.text = String(text.suffix(text.count - 1))
            default:
                pressedList.insert("-", at: 0)
                step.text = "-" + text
            }
        case ".":
            if text == "" {
                pressedList.append("0")
                pressedList.append(".")
                step.text = "0."
                return
            }
            if !floated {
                pressedList.append(".")
                step.text = text + "."
                floated = true
            }
        default:
            step.text = text + op
            pressedList.append(op)
        }
        lastOpButton.backgroundColor = #colorLiteral(red: 0.3019607843, green: 0.2980392157, blue: 0.4901960784, alpha: 1)
    }
    
    func cleanStep() {
        let steps: String = step.text ?? ""
        step.text = steps.replacingOccurrences(of: "^0{2,}|0{2,}$", with: "", options: .regularExpression)
    }
    
    @IBAction func calculate(_ sender: UIButton) {
        checkClear()
        cleanStep()
        if let steps = step.text {
            if steps == "" {
                return
            }
            
            if pressedList.suffix(2) == ["÷", "0"] {
                result.text = "0"
                return
            }
            
            let ansExp: NSExpression = NSExpression(format: step.text!)
            let ans: Double = ansExp.expressionValue(with: nil, context: nil) as! Double
            
            result.text = String(ans)
        }
    }
}

